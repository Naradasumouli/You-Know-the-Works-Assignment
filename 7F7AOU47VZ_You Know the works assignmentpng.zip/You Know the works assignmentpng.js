// JavaScript
document.getElementById('subscribeBtn').addEventListener('click', function() {
    var btn = document.getElementById('subscribeBtn');
    if (btn.textContent === 'Subscribe') {
        btn.textContent = 'Subscribed';
    } else {
        btn.textContent = 'Subscribe';
    }
});